#include "disk.h"
#include "util.h"

void selectSector(unsigned int sector)
{
    outb(0x1f6, 0xe0 | sector >> 24);   //select device and sector num
    outb(0x3f6, 0x02);                  //turn off interrupts
    outb(0x1f2, 0x01);		            //indicate read range 0 is for full 256 sectors
	outb(0x1f3, sector);                //low 8bits
	outb(0x1f4, sector >> 8);           //next 8bits
	outb(0x1f5, sector >> 16);	        //next 8bits
}

int isBusy()
{
    return inb(0x1f7) & 0x80; //return 0: not busy, or 1: busy
}

int isDiskReady()
{
    while(isBusy())                                 //wait while disk is working
        logString("Waiting for disk_ready!!\n\0");
    for(;;)
    {
        if(inb(0x1f7) & 8)                          //ready
            return 1;
        else if(inb(0x1f7) & 1 || inb(0x1f7) & 32)	//error bit toggled
            return -1;
    }
}

void disk_read_sector(unsigned sector, void* datablock)
{
    while(isBusy())
        logString("Waiting before disk_read!!\n\0");

    selectSector(sector);
    outb(0x1f7, 0x20);		 //start a read

    if(isDiskReady() == 1)
        logString("Disk Ready\n\0");
    else
    {
        logString("Disk Error!!\n\0");
    }
    unsigned index;
    for(index = 0; index < 256; ++index)
    {
        unsigned short data = inw(0x1f0);
        ((unsigned short*)datablock)[index] = data;
    }
}

void disk_write_sector(unsigned sector, const void* datablock)
{
    while(isBusy())
        logString("Waiting before disk_write!!\n\0");

    selectSector(sector);
    outb(0x1f7, 0x30);		 //start writting

    if(isDiskReady() == 1)
        logString("Disk Ready\n\0");
    else
    {
        logString("Disk Error!!\n\0");
    }
    unsigned short* dataToWrite = (void*)datablock;
    unsigned index;
    for(index = 0; index < 256; ++index)
    {
        outw(0x1f0, *dataToWrite);
        dataToWrite++;
    }
    outb(0x1f7, 0xe7);      //flush
}