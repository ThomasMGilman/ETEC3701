#include "util.h"

int consol_init(struct MultibootInfo *m);
int disk_init(void);
int kprintf(const char* fmt, ... ) __attribute__((format (printf , 1, 2 ) ));
void sweet();

void kmain(struct MultibootInfo *mbi){
    consol_init(mbi);   //initialize framebuffer and blank screen
    disk_init();
    sweet();
    while(1){;}           //loop forever
}