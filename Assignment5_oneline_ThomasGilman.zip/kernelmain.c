#include "util.h"


int consol_init(struct MultibootInfo *m);
void sweet();

void kmain(struct MultibootInfo *mbi){
    consol_init(mbi);   //initialize framebuffer and blank screen
    sweet();
    while(1){;}           //loop forever
}