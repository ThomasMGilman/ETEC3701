#include "util.h"
#include "font.h"
#pragma once

struct MultibootInfo *mbi;

void set_pixel(int x, int y, int r, int g, int b, struct MultibootInfo *mbi);

void smoothlyTransitionColors();

void consoleDrawChar(int x, int y, char ch, struct MultibootInfo *mbi);

void consoleDrawString(int *x, int *y, char* myString, struct MultibootInfo *mbi);

void consol_init(struct MultibootInfo *mbi);