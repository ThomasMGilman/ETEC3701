#include "console.h"

volatile unsigned char* framebuffer;
unsigned TopOfTRange[2] = {100,300}; 	//min and max range of top of T char
unsigned heightOfChars[2] = {100,200}; 	//min and max range of line of T char
unsigned TopOfGRange[2] = {350,450};	//min and max range of top line of G char

unsigned int colorChangeIndex = 0;
unsigned int colorPattern[6][3] = {{255,0,0}, {255,165,0}, {255,255,0}, {0,255,0}, {0,0,255}, {128,0,128}}; //Red,Orange,Yellow,Green,Blue,Purple
unsigned int red = 255, green = 255, blue = 0; 																//Color Variables (set to Yellow)



void set_pixel(int x, int y, int r, int g, int b, struct MultibootInfo *mbi)
{
	r >>= (8 - mbi->mbiFramebufferRedMask);
	g >>= (8 - mbi->mbiFramebufferGreenMask);
	b >>= (8 - mbi->mbiFramebufferBlueMask);

	unsigned short colorValue = (b << mbi->mbiFramebufferBluePos) | (g << mbi->mbiFramebufferGreenPos) | (r << mbi->mbiFramebufferRedPos);
	((unsigned short*)framebuffer)[(x+y*mbi->mbiFramebufferPitch)>>1] = colorValue;
}
void smoothlyTransitionColors()
{
	if(red != colorPattern[colorChangeIndex][0] || green != colorPattern[colorChangeIndex][1] || blue != colorPattern[colorChangeIndex][2])
	{
		if(red < colorPattern[colorChangeIndex][0]) red++;
		else if(red > colorPattern[colorChangeIndex][0]) red--;
		if(green < colorPattern[colorChangeIndex][1]) green++;
		else if( green > colorPattern[colorChangeIndex][1]) green--;
		if(blue < colorPattern[colorChangeIndex][2]) blue++;
		else if (blue > colorPattern[colorChangeIndex][2]) blue--;
	}
	else
	{
		if(colorChangeIndex == 5) colorChangeIndex = 0;
		else colorChangeIndex++;
	}
}
void consoleDrawChar(int x, int y, char ch, struct MultibootInfo *mbi)
{
	const int *c = font_data[(unsigned int)ch];
	int cx,cy;
	for(cy = 0; cy < CHAR_HEIGHT; cy++)
	{
		for(cx = 0; cx < CHAR_WIDTH; cx++)
		{
			if((MASK_VALUE >> cx) & c[cy]) 						//toggle the bit at index cx of 16bits
				set_pixel(x+cx, y+cy, red, green, blue, mbi);
			else
				set_pixel(x+cx, y+cy, 0, 0, 0, mbi);			//erase anything that isnt part of the char
		}
	}
}
void consoleDrawString(int* x, int* y, char* myString, struct MultibootInfo *mbi)
{
	int indexOfString = 0;
	while(myString[indexOfString])									//while not NULL
	{
		set_pixel(*x,*y,red,green,blue,mbi);
		consoleDrawChar(*x, *y, myString[indexOfString], mbi);		//print the char to screen from bottom left
		*x += CHAR_WIDTH; indexOfString++;							//move to next char in string literal and over on screen
	}
}
void consol_init(struct MultibootInfo *mbi)
{
    framebuffer = (volatile unsigned char*) (unsigned)mbi->mbiFramebufferAddress;
	char* myName = "Thomas Gilman";

	int screenPos_X, screenPos_Y;
	for(screenPos_Y=0; screenPos_Y<mbi->mbiFramebufferHeight; screenPos_Y++) 			//parse through each row of the screen
	{
		for(screenPos_X = 0; screenPos_X < mbi->mbiFramebufferWidth*2; screenPos_X++) 	//parse through each col of the screen
		{
			if(screenPos_X == 0 && screenPos_Y == 0)
				consoleDrawString(&screenPos_X, &screenPos_Y, myName, mbi);
		}
	}
	smoothlyTransitionColors();
}