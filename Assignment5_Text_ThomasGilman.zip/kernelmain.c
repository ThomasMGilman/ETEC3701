#include "console.h"

void sweet();

void kmain(){
    console_init();
    sweet();
    while(1){
    }
}



