#include "util.h"
#pragma once

void set_pixel(int x, int y, int r, int g, int b, struct MultibootInfo *mbi);

void smoothlyTransitionColors();

void consol_init(struct MultibootInfo *mbi);