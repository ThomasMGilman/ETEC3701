#include "console.h"
#include "util.h"

void kmain(struct MultibootInfo *mbi){
    while(1)
        consol_init(mbi);
    //Factorial(5);
    asm volatile (              //incode assembly, volatile tells compiler dont touch
        "mov esi, 0xf00d\n"     //move esi into register 0xf00d
        "hlt"
        ::: "memory");          //dont assume anything, dont mess with it as it could do with memory
    
}