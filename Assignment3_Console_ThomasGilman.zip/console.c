#include "console.h"

volatile unsigned char* framebuffer;
unsigned TopOfTRange[2] = {100,300}; 	//min and max range of top of T char
unsigned heightOfChars[2] = {100,200}; 	//min and max range of line of T char
unsigned TopOfGRange[2] = {350,450};	//min and max range of top line of G char

unsigned int colorChangeIndex = 0;
unsigned int colorPattern[6][3] = {{255,0,0}, {255,165,0}, {255,255,0}, {0,255,0}, {0,0,255}, {128,0,128}}; //Red,Orange,Yellow,Green,Blue,Purple
unsigned int red = 255, green = 255, blue = 0; 																//Color Variables (set to Yellow)

void set_pixel(int x, int y, int r, int g, int b, struct MultibootInfo *mbi)
{
	r >>= (8 - mbi->mbiFramebufferRedMask);
	g >>= (8 - mbi->mbiFramebufferGreenMask);
	b >>= (8 - mbi->mbiFramebufferBlueMask);

	unsigned short colorValue = (b << mbi->mbiFramebufferBluePos) | (g << mbi->mbiFramebufferGreenPos) | (r << mbi->mbiFramebufferRedPos);
	((unsigned short*)framebuffer)[(x+y*mbi->mbiFramebufferPitch)>>1] = colorValue;
}
void smoothlyTransitionColors()
{
	if(red != colorPattern[colorChangeIndex][0] || green != colorPattern[colorChangeIndex][1] || blue != colorPattern[colorChangeIndex][2])
	{
		if(red < colorPattern[colorChangeIndex][0]) red++;
		else if(red > colorPattern[colorChangeIndex][0]) red--;
		if(green < colorPattern[colorChangeIndex][1]) green++;
		else if( green > colorPattern[colorChangeIndex][1]) green--;
		if(blue < colorPattern[colorChangeIndex][2]) blue++;
		else if (blue > colorPattern[colorChangeIndex][2]) blue--;
	}
	else
	{
		if(colorChangeIndex == 5) colorChangeIndex = 0;
		else colorChangeIndex++;
	}
}
void consol_init(struct MultibootInfo *mbi)
{
    framebuffer = (volatile unsigned char*) (unsigned)mbi->mbiFramebufferAddress;

	//parse through each row of the screen
	for(int y=0; y<mbi->mbiFramebufferHeight; y++)
	{
		//parse through each col of the screen
		for(int x = 0; x < mbi->mbiFramebufferWidth*2; x++)
		{
			//draw T
			if((y == heightOfChars[0] && x >= TopOfTRange[0] && x <= TopOfTRange[1]) 
			|| (y >= heightOfChars[0] && y <= heightOfChars[1] && x == (TopOfTRange[1] - TopOfTRange[0])))
				set_pixel(x,y,red,green,blue,mbi);
			//draw G
			else if((y==heightOfChars[0] && x >= TopOfGRange[0] && x <= TopOfGRange[1]) 										//draw Top of G
			|| (y >= heightOfChars[0] && y <= heightOfChars[1] && x == TopOfGRange[0]) 											//draw left Side of G
			|| (y == heightOfChars[1] && x >= TopOfGRange[0] && x <= TopOfGRange[1]) 											//draw Bottom of G
			|| (y >= heightOfChars[1]/4 + heightOfChars[0] && y <= heightOfChars[1] && x == TopOfGRange[1]) 					//draw right side of G
			|| (y == heightOfChars[1]/4 + heightOfChars[0] && x >= TopOfGRange[1]/6 + TopOfGRange[0] && x <= TopOfGRange[1])) 	//draw - of G 
				set_pixel(x,y,red,green,blue,mbi);
		}
	}
	smoothlyTransitionColors();
}