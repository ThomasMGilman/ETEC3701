#pragma once

int exec(const char* filename);

void syscall_handler(unsigned* ptr);