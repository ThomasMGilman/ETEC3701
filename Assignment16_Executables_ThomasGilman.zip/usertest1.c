int main(int argc, char* argv[])
{
    register unsigned flag asm("esi");
    flag=0x31337;
    asm("hlt");
    while(flag)
    {;}
    return 0;
} 